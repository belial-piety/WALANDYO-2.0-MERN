require('dotenv').config();
const express = require('express');
const session = require('express-session');
const methodOverride = require('method-override');
const { engine } = require('express-handlebars');
const path = require('path');

const { attachViewLocals } = require('./middleware/auth');

const app = express();

// ---------------------------------------------------------------
// View engine: Handlebars, following the app's MVC "V" layer
// ---------------------------------------------------------------
app.engine(
  'handlebars',
  engine({
    defaultLayout: 'main',
    layoutsDir: path.join(__dirname, 'views', 'layouts'),
    partialsDir: path.join(__dirname, 'views', 'partials'),
    helpers: {
      formatCurrency: (value) =>
        `₱${Number(value || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      formatDate: (value) =>
        new Date(value).toLocaleString('en-PH', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
      eq: (a, b) => a === b,
      ne: (a, b) => a !== b,
      or: (a, b) => a || b,
      capitalize: (s) => (typeof s === 'string' ? s.charAt(0).toUpperCase() + s.slice(1) : s),
      statusClass: (status) => {
        const map = { ok: 'badge-green', low: 'badge-amber', out_of_stock: 'badge-red', completed: 'badge-green', voided: 'badge-red' };
        return map[status] || 'badge-gray';
      },
      json: (context) => JSON.stringify(context),
      // Usage in views: {{#if (roleIn currentUser.role "admin,manager")}}
      roleIn: (role, csvRoles) => typeof csvRoles === 'string' && csvRoles.split(',').includes(role),
    },
  })
);
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));

// ---------------------------------------------------------------
// Core middleware
// ---------------------------------------------------------------
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'walandyo-dev-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 8 * 60 * 60 * 1000 }, // 8-hour shift-length session
  })
);

app.use(attachViewLocals);

// ---------------------------------------------------------------
// Routes
// ---------------------------------------------------------------
app.use('/', require('./routes/index'));
app.use('/', require('./routes/auth'));
app.use('/counter', require('./routes/counter'));
app.use('/orders', require('./routes/orders'));
app.use('/menu', require('./routes/menu'));
app.use('/inventory', require('./routes/inventory'));
app.use('/reports', require('./routes/reports'));
app.use('/branches', require('./routes/branches'));
app.use('/staff', require('./routes/staff'));
app.use('/notifications', require('./routes/notifications'));

// ---------------------------------------------------------------
// 404 + error handling
// ---------------------------------------------------------------
app.use((req, res) => {
  res.status(404).render('errors/404', { title: 'Page not found', layout: 'main' });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render('errors/404', {
    title: 'Something went wrong',
    message: err.message,
    layout: 'main',
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Walandyo Tapsilogan POS running at http://localhost:${PORT}`);
});
